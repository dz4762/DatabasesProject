
INSERT INTO employee VALUES ('James','E','Borg','888665555', str_to_date('10-NOV-1927', '%d-%b-%Y'),'450 Stone, Houston, TX','M',55000,null,null);
INSERT INTO employee VALUES ('Franklin','T','Wong','333445555', str_to_date('08-DEC-1945', '%d-%b-%Y'),'638 Voss, Houston, TX','M',40000,'888665555',null);
INSERT INTO employee VALUES ('Jennifer','S','Wallace','987654321', str_to_date('20-JUN-1931', '%d-%b-%Y'),'291 Berry, Bellaire, TX','F',43000,'888665555',null);
INSERT INTO employee VALUES ('Jared','D','James','111111100',str_to_date('10-OCT-1966', '%d-%b-%Y'),'123 Peachtree, Atlanta, GA','M',85000,null,null);
INSERT INTO employee VALUES ('Alex','D','Freed','444444400',str_to_date('09-OCT-1950', '%d-%b-%Y'),'4333 Pillsbury, Milwaukee, WI','M',89000,null,null);
INSERT INTO employee VALUES ('John','C','James','555555500',str_to_date('30-JUN-1975', '%d-%b-%Y'),'7676 Bloomington, Sacramento, CA','M',81000,null,null);
--
INSERT INTO department VALUES (5, 'Research', '333445555', str_to_date('22-MAY-1978', '%d-%b-%Y'));
INSERT INTO department VALUES (4, 'Administration', '987654321', str_to_date('01-JAN-1985', '%d-%b-%Y'));
INSERT INTO department VALUES (1, 'Headquarters', '888665555', str_to_date('19-JUN-1971', '%d-%b-%Y'));
INSERT INTO department VALUES (6, 'Software','111111100',str_to_date('15-MAY-1999', '%d-%b-%Y'));
INSERT INTO department VALUES (7, 'Hardware','444444400',str_to_date('15-MAY-1998', '%d-%b-%Y'));
INSERT INTO department VALUES (8, 'Sales','555555500',str_to_date('01-JAN-1997', '%d-%b-%Y'));
--
UPDATE employee SET dno = 5 WHERE ssn = '333445555';
UPDATE employee SET dno = 4 WHERE ssn = '987654321';
UPDATE employee SET dno = 1 WHERE ssn = '888665555';
UPDATE employee SET dno = 6 WHERE ssn = '111111100';
UPDATE employee SET dno = 7 WHERE ssn = '444444400';
UPDATE employee SET dno = 6 WHERE ssn = '555555500';
--
INSERT INTO employee VALUES 
  ('John','B','Smith','123456789',str_to_date('09-Jan-1955', '%d-%b-%Y'),'731 Fondren, Houston, TX','M',30000,'333445555',5);
INSERT INTO employee VALUES 
  ('Alicia','J','Zelaya','999887777',str_to_date('19-JUL-1958', '%d-%b-%Y'),'3321 Castle, Spring, TX','F',25000,'987654321',4);
INSERT INTO employee VALUES 
  ('Ramesh','K','Narayan','666884444',str_to_date('15-SEP-1952', '%d-%b-%Y'),'971 Fire Oak, Humble, TX','M',38000,'333445555',5);
INSERT INTO employee VALUES 
  ('Joyce','A','English','453453453',str_to_date('31-JUL-1962', '%d-%b-%Y'),'5631 Rice Oak, Houston, TX','F',25000,'333445555',5);
INSERT INTO employee VALUES 
  ('Ahmad','V','Jabbar','987987987',str_to_date('29-MAR-1959', '%d-%b-%Y'),'980 Dallas, Houston, TX','M',25000,'987654321',4);
insert into employee values
  ('Jon','C','Jones','111111101',str_to_date('14-NOV-1967', '%d-%b-%Y'),'111 Allgood, Atlanta, GA','M',45000,'111111100',6);
insert into employee values
  ('Justin',null,'Mark','111111102',str_to_date('12-JAN-1966', '%d-%b-%Y'),'2342 May, Atlanta, GA','M',40000,'111111100',6);
insert into employee values
  ('Brad','C','Knight','111111103',str_to_date('13-FEB-1968', '%d-%b-%Y'),'176 Main St., Atlanta, GA','M',44000,'111111100',6);
insert into employee values
  ('Evan','E','Wallis','222222200',str_to_date('16-JAN-1958', '%d-%b-%Y'),'134 Pelham, Milwaukee, WI','M',92000,null,7);
insert into employee values
  ('Josh','U','Zell','222222201',str_to_date('22-MAY-1954', '%d-%b-%Y'),'266 McGrady, Milwaukee, WI','M',56000,'222222200',7);
insert into employee values
  ('Andy','C','Vile','222222202',str_to_date('21-JUN-1944', '%d-%b-%Y'),'1967 Jordan, Milwaukee, WI','M',53000,'222222200',7);
insert into employee values
  ('Tom','G','Brand','222222203',str_to_date('16-DEC-1966', '%d-%b-%Y'),'112 Third St, Milwaukee, WI','M',62500,'222222200',7);
insert into employee values
  ('Jenny','F','Vos','222222204',str_to_date('11-NOV-1967', '%d-%b-%Y'),'263 Mayberry, Milwaukee, WI','F',61000,'222222201',7);
insert into employee values
  ('Chris','A','Carter','222222205',str_to_date('21-MAR-1960', '%d-%b-%Y'),'565 Jordan, Milwaukee, WI','F',43000,'222222201',7);
insert into employee values
  ('Kim','C','Grace','333333300',str_to_date('23-OCT-1970', '%d-%b-%Y'),'6677 Mills Ave, Sacramento, CA','F',79000,null,6);
insert into employee values
  ('Jeff','H','Chase','333333301',str_to_date('07-JAN-1970', '%d-%b-%Y'),'145 Bradbury, Sacramento, CA','M',44000,'333333300',6);
insert into employee values
  ('Bonnie','S','Bays','444444401',str_to_date('19-JUN-1956', '%d-%b-%Y'),'111 Hollow, Milwaukee, WI','F',70000,'444444400',7);
insert into employee values
  ('Alec','C','Best','444444402',str_to_date('18-JUN-1966', '%d-%b-%Y'),'233 Solid, Milwaukee, WI','M',60000,'444444400',7);
insert into employee values
  ('Sam','S','Snedden','444444403',str_to_date('31-JUL-1977', '%d-%b-%Y'),'987 Windy St, Milwaukee, WI','M',48000,'444444400',7);
insert into employee values
  ('Nandita','K','Ball','555555501',str_to_date('16-APR-1969', '%d-%b-%Y'),'222 Howard, Sacramento, CA','M',62000,'555555500',6);
insert into employee values
  ('Bob','B','Bender','666666600',str_to_date('17-APR-1968', '%d-%b-%Y'),'8794 Garfield, Chicago, IL','M',96000,null,8);
insert into employee values
  ('Jill','J','Jarvis','666666601',str_to_date('14-JAN-1966', '%d-%b-%Y'),'6234 Lincoln, Chicago, IL','F',36000,'666666600',8);
insert into employee values
  ('Kate','W','King','666666602',str_to_date('16-APR-1966', '%d-%b-%Y'),'1976 Boone Trace, Chicago, IL','F',44000,'666666600',8);
insert into employee values
  ('Lyle','G','Leslie','666666603',str_to_date('09-JUN-1963', '%d-%b-%Y'),'417 Hancock Ave, Chicago, IL','M',41000,'666666601',8);
insert into employee values
  ('Billie','J','King','666666604',str_to_date('01-JAN-1960', '%d-%b-%Y'),'556 Washington, Chicago, IL','F',38000,'666666603',8);
insert into employee values
  ('Jon','A','Kramer','666666605',str_to_date('22-AUG-1964', '%d-%b-%Y'),'1988 Windy Creek, Seattle, WA','M',41500,'666666603',8);
insert into employee values
  ('Ray','H','King','666666606',str_to_date('16-AUG-1949', '%d-%b-%Y'),'213 Delk Road, Seattle, WA','M',44500,'666666604',8);
insert into employee values
  ('Gerald','D','Small','666666607',str_to_date('15-MAY-1962', '%d-%b-%Y'),'122 Ball Street, Dallas, TX','M',29000,'666666602',8);
insert into employee values
  ('Arnold','A','Head','666666608',str_to_date('19-MAY-1967', '%d-%b-%Y'),'233 Spring St, Dallas, TX','M',33000,'666666602',8);
insert into employee values
  ('Helga','C','Pataki','666666609',str_to_date('11-MAR-1969', '%d-%b-%Y'),'101 Holyoke St, Dallas, TX','F',32000,'666666602',8);
insert into employee values
  ('Naveen','B','Drew','666666610',str_to_date('23-MAY-1970', '%d-%b-%Y'),'198 Elm St, Philadelphia, PA','M',34000,'666666607',8);
insert into employee values
  ('Carl','E','Reedy','666666611',str_to_date('21-JUN-1977', '%d-%b-%Y'),'213 Ball St, Philadelphia, PA','M',32000,'666666610',8);
insert into employee values
  ('Sammy','G','Hall','666666612',str_to_date('11-JAN-1970', '%d-%b-%Y'),'433 Main Street, Miami, FL','M',37000,'666666611',8);
insert into employee values
  ('Red','A','Bacher','666666613',str_to_date('21-MAY-1980', '%d-%b-%Y'),'196 Elm Street, Miami, FL','M',33500,'666666612',8);
--
INSERT INTO project VALUES ('ProductX',1,'Bellaire',5);
INSERT INTO project VALUES ('ProductY',2,'Sugarland',5);
INSERT INTO project VALUES ('ProductZ',3,'Houston',5);
INSERT INTO project VALUES ('Computerization',10,'Stafford',4);
INSERT INTO project VALUES ('Reorganization',20,'Houston',1);
INSERT INTO project VALUES ('Newbenefits',30,'Stafford',4);
INSERT INTO project VALUES ('OperatingSystems',61,'Jacksonville',6);
INSERT INTO project VALUES ('DatabaseSystems',62,'Birmingham',6);
INSERT INTO project VALUES ('Middleware',63,'Jackson',6);
INSERT INTO project VALUES ('InkjetPrinters',91,'Phoenix',7);
INSERT INTO project VALUES ('LaserPrinters',92,'LasVegas',7);
--
INSERT INTO dept_locations VALUES (1,'Houston');
INSERT INTO dept_locations VALUES (4,'Stafford');
INSERT INTO dept_locations VALUES (5,'Bellaire');
INSERT INTO dept_locations VALUES (5,'Sugarland');
INSERT INTO dept_locations VALUES (5,'Houston');
INSERT INTO dept_locations VALUES (6,'Atlanta');
INSERT INTO dept_locations VALUES (6,'Sacramento');
INSERT INTO dept_locations VALUES (7,'Milwaukee');
INSERT INTO dept_locations VALUES (8,'Chicago');
INSERT INTO dept_locations VALUES (8,'Dallas');
INSERT INTO dept_locations VALUES (8,'Philadephia');
INSERT INTO dept_locations VALUES (8,'Seattle');
INSERT INTO dept_locations VALUES (8,'Miami');
--
INSERT INTO dependent VALUES ('333445555','Alice','F',str_to_date('05-APR-1976', '%d-%b-%Y'),'Daughter');
INSERT INTO dependent VALUES ('333445555','Theodore','M',str_to_date('25-OCT-1973', '%d-%b-%Y'),'Son');
INSERT INTO dependent VALUES ('333445555','Joy','F',str_to_date('03-MAY-1948', '%d-%b-%Y'),'Spouse');
INSERT INTO dependent VALUES ('987654321','Abner','M',str_to_date('29-FEB-1932', '%d-%b-%Y'),'Spouse');
INSERT INTO dependent VALUES ('123456789','Michael','M',str_to_date('01-JAN-1978', '%d-%b-%Y'),'Son');
INSERT INTO dependent VALUES ('123456789','Alice','F', str_to_date('31-DEC-1978', '%d-%b-%Y'),'Daughter');
INSERT INTO dependent VALUES ('123456789','Elizabeth','F',str_to_date('05-MAY-1957', '%d-%b-%Y'),'Spouse');
INSERT INTO dependent VALUES ('444444400','Johnny','M',str_to_date('04-APR-1997', '%d-%b-%Y'),'Son');
INSERT INTO dependent VALUES ('444444400','Tommy','M',str_to_date('07-JUN-1999', '%d-%b-%Y'),'Son');
INSERT INTO dependent VALUES ('444444401','Chris','M',str_to_date('19-APR-1969', '%d-%b-%Y'),'Spouse');
INSERT INTO dependent VALUES ('444444402','Jane','F',str_to_date('14-FEB-1964', '%d-%b-%Y'),'Spouse');
INSERT INTO dependent VALUES ('444444402','Alec','M',str_to_date('14-FEB-1964', '%d-%b-%Y'),'Son');
INSERT INTO dependent VALUES ('444444402','Jeff','M',str_to_date('14-FEB-1967', '%d-%b-%Y'),'Son');

--
INSERT INTO works_on VALUES ('123456789',1, 32.5);
INSERT INTO works_on VALUES ('123456789',2,  7.5);
INSERT INTO works_on VALUES ('666884444',3, 40.0);
INSERT INTO works_on VALUES ('453453453',1, 20.0);
INSERT INTO works_on VALUES ('453453453',2, 20.0);
INSERT INTO works_on VALUES ('333445555',2, 10.0);
INSERT INTO works_on VALUES ('333445555',3, 10.0);
INSERT INTO works_on VALUES ('333445555',10,10.0);
INSERT INTO works_on VALUES ('333445555',20,10.0);
INSERT INTO works_on VALUES ('999887777',30,30.0);
INSERT INTO works_on VALUES ('999887777',10,10.0);
INSERT INTO works_on VALUES ('987987987',10,35.0);
INSERT INTO works_on VALUES ('987987987',30, 5.0);
INSERT INTO works_on VALUES ('987654321',30,20.0);
INSERT INTO works_on VALUES ('987654321',20,15.0);
INSERT INTO works_on VALUES ('888665555',20,null);
INSERT INTO works_on VALUES ('111111100',61,40.0);
INSERT INTO works_on VALUES ('111111101',61,40.0);
INSERT INTO works_on VALUES ('111111102',61,40.0);
INSERT INTO works_on VALUES ('111111103',61,40.0);
INSERT INTO works_on VALUES ('222222200',62,40.0);
INSERT INTO works_on VALUES ('222222201',62,48.0);
INSERT INTO works_on VALUES ('222222202',62,40.0);
INSERT INTO works_on VALUES ('222222203',62,40.0);
INSERT INTO works_on VALUES ('222222204',62,40.0);
INSERT INTO works_on VALUES ('222222205',62,40.0);
INSERT INTO works_on VALUES ('333333300',63,40.0);
INSERT INTO works_on VALUES ('333333301',63,46.0);
INSERT INTO works_on VALUES ('444444400',91,40.0);
INSERT INTO works_on VALUES ('444444401',91,40.0);
INSERT INTO works_on VALUES ('444444402',91,40.0);
INSERT INTO works_on VALUES ('444444403',91,40.0);
INSERT INTO works_on VALUES ('555555500',92,40.0);
INSERT INTO works_on VALUES ('555555501',92,44.0);
INSERT INTO works_on VALUES ('666666601',91,40.0);
INSERT INTO works_on VALUES ('666666603',91,40.0);
INSERT INTO works_on VALUES ('666666604',91,40.0);
INSERT INTO works_on VALUES ('666666605',92,40.0);
INSERT INTO works_on VALUES ('666666606',91,40.0);
INSERT INTO works_on VALUES ('666666607',61,40.0);
INSERT INTO works_on VALUES ('666666608',62,40.0);
INSERT INTO works_on VALUES ('666666609',63,40.0);
INSERT INTO works_on VALUES ('666666610',61,40.0);
INSERT INTO works_on VALUES ('666666611',61,40.0);
INSERT INTO works_on VALUES ('666666612',61,40.0);
INSERT INTO works_on VALUES ('666666613',61,30.0);
INSERT INTO works_on VALUES ('666666613',62,10.0);
INSERT INTO works_on VALUES ('666666613',63,10.0);

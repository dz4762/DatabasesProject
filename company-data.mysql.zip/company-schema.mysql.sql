SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema company
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `company` DEFAULT CHARACTER SET utf8 ;
USE `company` ;

-- -----------------------------------------------------
-- Table `company`.`employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `company`.`employee` (
  `fname` VARCHAR(15) NOT NULL,
  `minit` VARCHAR(1) NULL DEFAULT NULL,
  `lname` VARCHAR(15) NOT NULL,
  `ssn` CHAR(9) NOT NULL DEFAULT '',
  `bdate` DATE NULL DEFAULT NULL,
  `address` VARCHAR(50) NULL DEFAULT NULL,
  `sex` CHAR(1) NULL DEFAULT NULL,
  `salary` DECIMAL(10,2) NULL DEFAULT NULL,
  `superssn` CHAR(9) NULL DEFAULT NULL,
  `dno` BIGINT NULL,
  PRIMARY KEY (`ssn`),
  INDEX `superssn` (`superssn` ASC),
  INDEX `dno` (`dno` ASC),
  CONSTRAINT `employee_ibfk_2`
    FOREIGN KEY (`dno`)
    REFERENCES `company`.`department` (`dnumber`),
  CONSTRAINT `employee_ibfk_1`
    FOREIGN KEY (`superssn`)
    REFERENCES `company`.`employee` (`ssn`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `company`.`department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `company`.`department` (
  `dnumber` BIGINT NOT NULL DEFAULT '0',
  `dname` VARCHAR(25) NOT NULL,
  `mgrssn` CHAR(9) NOT NULL,
  `mgrstartdate` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`dnumber`),
  UNIQUE INDEX `dname` (`dname` ASC),
  INDEX `mgrssn` (`mgrssn` ASC),
  CONSTRAINT `department_ibfk_1`
    FOREIGN KEY (`mgrssn`)
    REFERENCES `company`.`employee` (`ssn`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `company`.`dependent`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `company`.`dependent` (
  `essn` CHAR(9) NOT NULL DEFAULT '',
  `dependent_name` VARCHAR(15) NOT NULL DEFAULT '',
  `sex` CHAR(1) NULL DEFAULT NULL,
  `bdate` DATE NULL DEFAULT NULL,
  `relationship` VARCHAR(8) NULL DEFAULT NULL,
  PRIMARY KEY (`essn`, `dependent_name`),
  CONSTRAINT `dependent_ibfk_1`
    FOREIGN KEY (`essn`)
    REFERENCES `company`.`employee` (`ssn`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `company`.`dept_locations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `company`.`dept_locations` (
  `dnumber` BIGINT NOT NULL DEFAULT '0',
  `dlocation` VARCHAR(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`dnumber`, `dlocation`),
  CONSTRAINT `dept_locations_ibfk_1`
    FOREIGN KEY (`dnumber`)
    REFERENCES `company`.`department` (`dnumber`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `company`.`project`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `company`.`project` (
  `pname` VARCHAR(25) NOT NULL,
  `pnumber` BIGINT NOT NULL DEFAULT '0',
  `plocation` VARCHAR(15) NULL DEFAULT NULL,
  `dnum` BIGINT NOT NULL,
  PRIMARY KEY (`pnumber`),
  UNIQUE INDEX `pname` (`pname` ASC),
  INDEX `dnum` (`dnum` ASC),
  CONSTRAINT `project_ibfk_1`
    FOREIGN KEY (`dnum`)
    REFERENCES `company`.`department` (`dnumber`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `company`.`works_on`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `company`.`works_on` (
  `essn` CHAR(9) NOT NULL DEFAULT '',
  `pno` BIGINT NOT NULL DEFAULT '0',
  `hours` DECIMAL(4,1) NULL DEFAULT NULL,
  PRIMARY KEY (`essn`, `pno`),
  INDEX `pno` (`pno` ASC),
  CONSTRAINT `works_on_ibfk_1`
    FOREIGN KEY (`essn`)
    REFERENCES `company`.`employee` (`ssn`),
  CONSTRAINT `works_on_ibfk_2`
    FOREIGN KEY (`pno`)
    REFERENCES `company`.`project` (`pnumber`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
